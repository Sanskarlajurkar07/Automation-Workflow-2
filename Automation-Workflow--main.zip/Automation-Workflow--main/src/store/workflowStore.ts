import { create } from 'zustand';
import type { Node, Connection, Workflow } from '../types/workflow';

interface WorkflowState {
  workflows: Workflow[];
  currentWorkflow: Workflow | null;
  addWorkflow: (workflow: Workflow) => void;
  setCurrentWorkflow: (workflow: Workflow) => void;
  addNode: (node: Node) => void;
  addConnection: (connection: Connection) => void;
}

export const useWorkflowStore = create<WorkflowState>((set) => ({
  workflows: [],
  currentWorkflow: null,
  addWorkflow: (workflow) =>
    set((state) => ({ workflows: [...state.workflows, workflow] })),
  setCurrentWorkflow: (workflow) => set({ currentWorkflow: workflow }),
  addNode: (node) =>
    set((state) => ({
      currentWorkflow: state.currentWorkflow
        ? {
            ...state.currentWorkflow,
            nodes: [...state.currentWorkflow.nodes, node],
          }
        : null,
    })),
  addConnection: (connection) =>
    set((state) => ({
      currentWorkflow: state.currentWorkflow
        ? {
            ...state.currentWorkflow,
            connections: [...state.currentWorkflow.connections, connection],
          }
        : null,
    })),
}));