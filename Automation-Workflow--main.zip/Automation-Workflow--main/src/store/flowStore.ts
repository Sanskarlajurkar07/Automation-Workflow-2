import { create } from 'zustand';
import { 
  Connection, 
  addEdge, 
  applyNodeChanges, 
  applyEdgeChanges,
  MarkerType,
} from 'reactflow';
import { FlowNode, FlowEdge, NodeType } from '../types/flow';
import type { Template } from '../types/template';

interface FlowState {
  nodes: FlowNode[];
  edges: FlowEdge[];
  nodeCounters: Record<string, number>;
  selectedNode: FlowNode | null;
  selectedTemplate: Template | null;
  onNodesChange: (changes: any) => void;
  onEdgesChange: (changes: any) => void;
  onConnect: (connection: Connection) => void;
  updateNodeParams: (nodeId: string, params: any) => void;
  updateNodeResults: (nodeId: string, results: any) => void;
  loadTemplate: (template: Template) => void;
  getNextNodeId: (type: NodeType) => string;
  removeNode: (nodeId: string) => void;
  setSelectedNode: (node: FlowNode | null) => void;
  clearWorkflow: () => void;
  setEdges: (updater: (edges: FlowEdge[]) => FlowEdge[]) => void; // Add setEdges
  updateNodeData: (id: string, params: any) => void; // Add updateNodeData
}

export const useFlowStore = create<FlowState>((set, get) => ({
  nodes: [],
  edges: [],
  nodeCounters: {},
  selectedNode: null,
  selectedTemplate: null,

  getNextNodeId: (type: NodeType) => {
    const state = get();
    const counter = state.nodeCounters[type] || 0;
    set({ nodeCounters: { ...state.nodeCounters, [type]: counter + 1 } });
    return `${type}_${counter}`;
  },

  addNode: (type: NodeType, position: { x: number; y: number }) => {
    const nodeId = get().getNextNodeId(type);
    const newNode: FlowNode = {
      id: nodeId,
      type,
      position,
      data: {
        label: type,
        type,
        params: {
          nodeName: nodeId
        }
      }
    };

    set((state) => ({
      nodes: [...state.nodes, newNode]
    }));
    
    return newNode;
  },

  onNodesChange: (changes) => {
    set({
      nodes: applyNodeChanges(changes, get().nodes),
    });
  },

  onEdgesChange: (changes) => {
    set({
      edges: applyEdgeChanges(changes, get().edges),
    });
  },

  onConnect: (connection) => {
    const newEdge = {
      ...connection,
      type: 'smoothstep',
      markerEnd: { type: MarkerType.ArrowClosed },
      animated: true,
    };
    set({
      edges: addEdge(newEdge, get().edges),
    });
  },

  updateNodeParams: (nodeId, params) => {
    set({
      nodes: get().nodes.map((node) => {
        if (node.id === nodeId) {
          return {
            ...node,
            data: {
              ...node.data,
              params: {
                ...node.data.params,
                ...params,
              },
            },
          };
        }
        return node;
      }),
    });
  },

  updateNodeResults: (nodeId, results) => {
    set({
      nodes: get().nodes.map((node) => {
        if (node.id === nodeId) {
          return {
            ...node,
            data: {
              ...node.data,
              results,
            },
          };
        }
        return node;
      }),
    });
  },

  loadTemplate: (template) => {
    set({
      nodes: template.nodes,
      edges: template.edges,
      selectedTemplate: template,
    });
  },

  removeNode: (id) => {
    set((state) => ({
      nodes: state.nodes.filter((node) => node.id !== id),
    }));
  },

  setSelectedNode: (node) => {
    set({ selectedNode: node });
  },

  clearWorkflow: () => {
    set({
      nodes: [],
      edges: [],
      selectedNode: null,
      selectedTemplate: null,
    });
  },

  setEdges: (updater) => {
    set({
      edges: updater(get().edges),
    });
  },

  updateNodeData: (id, params) => {
    set((state) => ({
      nodes: state.nodes.map((node) =>
        node.id === id
          ? { ...node, data: { ...node.data, params: { ...node.data.params, ...params } } }
          : node
      ),
    }));
  },
}));