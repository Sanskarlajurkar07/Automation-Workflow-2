import React from 'react';
import { DashboardHeader } from './DashboardHeader';
import { DashboardSidebar } from './DashboardSidebar';
import { Analytics } from './Analytics';
import { ChartWidget } from './Widgets/ChartWidget';
import { StatWidget } from './Widgets/StatWidget';
import { Brain, Workflow, Database, Clock } from 'lucide-react';
import { Link } from 'react-router-dom';
import { Plus } from 'lucide-react';

export const Dashboard = () => {
  return (
    <div className="flex h-screen bg-gradient-to-br from-gray-900 via-gray-800 to-black text-white">
      <DashboardSidebar />
      
      <div className="flex-1 flex flex-col overflow-hidden">
        <DashboardHeader />
        
        <main className="flex-1 overflow-y-auto">
          <div className="p-8 max-w-7xl mx-auto">
            <div className="mb-10 flex items-center justify-between">
              <div>
                <h1 className="text-3xl font-bold bg-gradient-to-r from-blue-400 to-purple-400 bg-clip-text text-transparent">
                  Welcome back
                </h1>
                <p className="text-gray-400 mt-2">Monitor your AI workflows and system performance</p>
              </div>
              {/* Create Workflow Button */}
              <Link
                to="/workflow/create"
                className="flex items-center px-4 py-2 bg-blue-600 text-white text-sm font-medium rounded-md hover:bg-blue-700"
              >
                <Plus className="w-4 h-4 mr-2" />
                Create Workflow
              </Link>
            </div>

            {/* Stats Grid */}
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-10">
              <StatWidget
                title="Active Workflows"
                value="24"
                change="+12%"
                trend="up"
                icon={<Workflow className="w-6 h-6 text-blue-400" />}
                className="bg-gray-800/50 border border-gray-700/50 backdrop-blur-xl"
              />
              <StatWidget
                title="AI Models Used"
                value="8"
                change="+3"
                trend="up"
                icon={<Brain className="w-6 h-6 text-purple-400" />}
                className="bg-gray-800/50 border border-gray-700/50 backdrop-blur-xl"
              />
              <StatWidget
                title="Database Size"
                value="2.4 GB"
                change="+0.8 GB"
                trend="up"
                icon={<Database className="w-6 h-6 text-emerald-400" />}
                className="bg-gray-800/50 border border-gray-700/50 backdrop-blur-xl"
              />
              <StatWidget
                title="Avg. Response Time"
                value="245ms"
                change="-18%"
                trend="down"
                icon={<Clock className="w-6 h-6 text-cyan-400" />}
                className="bg-gray-800/50 border border-gray-700/50 backdrop-blur-xl"
              />
            </div>

            {/* Charts Grid */}
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 mb-10">
              <ChartWidget
                title="Workflow Performance"
                description="Response times and success rates over time"
                className="bg-gray-800/50 border border-gray-700/50 backdrop-blur-xl"
              />
              <ChartWidget
                title="Resource Usage"
                description="CPU, Memory, and API call statistics"
                className="bg-gray-800/50 border border-gray-700/50 backdrop-blur-xl"
              />
            </div>

            <Analytics />
          </div>
        </main>
      </div>
    </div>
  );
};