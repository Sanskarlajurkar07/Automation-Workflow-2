import React from 'react';
import { Link } from 'react-router-dom';
import { 
  Brain, 
  LayoutDashboard, 
  Workflow, 
  Database, 
  Box,
  Rocket,
  Users,
  Terminal,
  Wand2,
  Plus
} from 'lucide-react';

const navigation = [
  { name: 'Dashboard', icon: LayoutDashboard, href: '/dashboard' },
  { name: 'Workflows', icon: Workflow, href: '/workflow' },
  { name: 'Data Hub', icon: Database, href: '/data-hub' }, // Moved to the top
  { name: 'Assets', icon: Box, href: '/assets' },
  { name: 'Applications', icon: Rocket, href: '/applications' },
  { name: 'Teams', icon: Users, href: '/teams' },
  { name: 'API Docs', icon: Terminal, href: '/api-docs' },
  { name: 'Scripts', icon: Wand2, href: '/scripts' },
];

export const DashboardSidebar = () => {
  return (
    <div className="flex flex-col w-64 bg-gray-900">
      <div className="flex items-center h-16 px-4 bg-gray-900 border-b border-gray-700">
        <Brain className="w-8 h-8 text-purple-400" />
        <span className="ml-2 text-xl font-bold text-white">FlowMind AI</span>
      </div>
      
      <nav className="flex-1 px-2 py-4 space-y-1">
        {/* Create Workflow Button - Moved to top */}
        <Link 
          to="/workflow/create" 
          className="flex items-center justify-center px-4 py-3 mb-4 text-sm font-medium text-white bg-gradient-to-r from-blue-600 to-purple-600 rounded-lg hover:from-blue-700 hover:to-purple-700 transition-all shadow-lg shadow-purple-500/20 hover:shadow-purple-500/30 group"
        >
          <Plus className="w-5 h-5 mr-2" />
          Create Workflow
        </Link>

        {/* Regular navigation items */}
        {navigation.map((item) => (
          <Link
            key={item.name}
            to={item.href}
            className="flex items-center px-3 py-2 text-sm font-medium text-gray-300 rounded-md hover:bg-gray-800 hover:text-white group"
          >
            <item.icon className="w-5 h-5 mr-3 text-gray-400 group-hover:text-white" />
            {item.name}
          </Link>
        ))}
      </nav>
    </div>
  );
};