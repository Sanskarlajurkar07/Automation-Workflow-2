import React, { useState } from 'react';
import { Handle, Position } from 'reactflow';
import { Settings, Trash2, Copy, Sparkles, Eye, EyeOff } from 'lucide-react';
import { useFlowStore } from '../../../../store/flowStore';

interface OpenAINodeProps {
  id: string;
  data: {
    params?: {
      nodeName?: string;
      system?: string;
      prompt?: string;
      model?: string;
      apiKey?: string;
      usePersonalKey?: boolean;
      finetunedModel?: string;
      showSettings?: boolean;
    };
  };
  selected?: boolean;
}

const modelOptions = [
  'gpt-4-turbo-preview',
  'gpt-4-0125-preview',
  'gpt-4-1106-preview',
  'gpt-4',
  'gpt-3.5-turbo-0125',
  'gpt-3.5-turbo',
  'text-embedding-3-small',
  'text-embedding-3-large',
  'whisper-1',
  'tts-1',
  'tts-1-hd',
  'dall-e-3',
  'dall-e-2'
];

const OpenAINode: React.FC<OpenAINodeProps> = ({ id, data, selected }) => {
  const [showApiKey, setShowApiKey] = useState(false);
  const removeNode = useFlowStore((state) => state.removeNode);
  const updateNodeData = useFlowStore((state) => state.updateNodeData);

  const handleToggleSettings = () => {
    updateNodeData(id, { showSettings: !data.params?.showSettings });
  };

  const handleCopyNodeId = () => {
    navigator.clipboard.writeText(id);
  };

  return (
    <div className={`bg-white rounded-lg shadow-md overflow-hidden ${
      selected ? 'ring-2 ring-blue-500' : 'border border-gray-200'
    }`}>
      {/* Header */}
      <div className="bg-gradient-to-r from-emerald-500 to-green-600 px-4 py-3">
        <div className="flex items-center justify-between">
          <div className="flex items-center space-x-3">
            <div className="p-2 bg-white/20 backdrop-blur-sm rounded-lg">
              <Sparkles className="w-5 h-5 text-white" />
            </div>
            <div>
              <h3 className="font-medium text-white">OpenAI</h3>
              <p className="text-xs text-emerald-50/80">
                {data.params?.model || 'Select model'}
              </p>
            </div>
          </div>
          <div className="flex items-center space-x-2">
            <button
              onClick={handleCopyNodeId}
              className="p-1.5 rounded-lg text-white/70 hover:text-white hover:bg-white/20 transition-colors"
              title="Copy Node ID"
            >
              <Copy className="w-4 h-4" />
            </button>
            <button
              onClick={handleToggleSettings}
              className="p-1.5 rounded-lg text-white/70 hover:text-white hover:bg-white/20 transition-colors"
              title="Settings"
            >
              <Settings className="w-4 h-4" />
            </button>
            <button
              onClick={() => removeNode(id)}
              className="p-1.5 rounded-lg text-white/70 hover:text-white hover:bg-red-400/20 transition-colors"
              title="Delete"
            >
              <Trash2 className="w-4 h-4" />
            </button>
          </div>
        </div>
      </div>

      {/* Content */}
      <div className="p-4 space-y-4">
        {/* Node Name */}
        <div className="space-y-2">
          <input
            type="text"
            value={data.params?.nodeName || 'openai_0'}
            onChange={(e) => updateNodeData(id, { nodeName: e.target.value })}
            className="w-full px-3 py-1.5 text-sm bg-gray-50 border border-gray-200 rounded-lg focus:ring-2 focus:ring-emerald-500 focus:border-transparent"
          />
        </div>

        {/* System Instructions */}
        <div className="space-y-2">
          <label className="flex items-center justify-between">
            <span className="text-xs font-medium text-gray-500">System Instructions</span>
            <div className="flex items-center space-x-2">
              <button
                onClick={() => updateNodeData(id, { system: '' })}
                className="text-xs text-gray-400 hover:text-gray-600"
              >
                Clear
              </button>
            </div>
          </label>
          <textarea
            value={data.params?.system || ''}
            onChange={(e) => updateNodeData(id, { system: e.target.value })}
            placeholder="Enter system instructions..."
            className="w-full rounded-md border-gray-300 shadow-sm focus:border-emerald-500 focus:ring-emerald-500 sm:text-sm"
          />
        </div>

        {/* Prompt */}
        <div>
          <label className="block text-sm font-medium text-gray-700">Prompt</label>
          <textarea
            className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-emerald-500 focus:ring-emerald-500 sm:text-sm"
            value={data.params?.prompt || ''}
            onChange={(e) => updateNodeData(id, { prompt: e.target.value })}
            placeholder="Type {{}} to utilize variables. E.g., Question: {{input_0.text}}"
          />
        </div>

        {/* Model */}
        <div>
          <label className="block text-sm font-medium text-gray-700">Model</label>
          <select
            className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-emerald-500 focus:ring-emerald-500 sm:text-sm"
            value={data.params?.model || ''}
            onChange={(e) => updateNodeData(id, { model: e.target.value })}
          >
            <option value="">Select a model</option>
            {modelOptions.map((model) => (
              <option key={model} value={model}>
                {model}
              </option>
            ))}
          </select>
        </div>

        {/* API Key */}
        <div>
          <label className="block text-sm font-medium text-gray-700">API Key</label>
          <div className="relative">
            <input
              type={showApiKey ? 'text' : 'password'}
              className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-emerald-500 focus:ring-emerald-500 sm:text-sm"
              value={data.params?.apiKey || ''}
              onChange={(e) => updateNodeData(id, { apiKey: e.target.value })}
              placeholder="Enter your API Key"
            />
            <button
              type="button"
              className="absolute inset-y-0 right-0 pr-3 flex items-center text-sm leading-5"
              onClick={() => setShowApiKey(!showApiKey)}
            >
              {showApiKey ? <EyeOff className="w-4 h-4 text-gray-400" /> : <Eye className="w-4 h-4 text-gray-400" />}
            </button>
          </div>
          <p className="mt-1 text-xs text-gray-500">Do not share API Key with anyone you do not trust!</p>
        </div>

        {/* Finetuned Model */}
        <div>
          <label className="block text-sm font-medium text-gray-700">Finetuned Model ID</label>
          <input
            type="text"
            className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-emerald-500 focus:ring-emerald-500 sm:text-sm"
            value={data.params?.finetunedModel || ''}
            onChange={(e) => updateNodeData(id, { finetunedModel: e.target.value })}
            placeholder="Enter your finetuned model ID"
          />
        </div>
      </div>

        {/* Handles */}
            <Handle
              type="target"
              position={Position.Left}
              className="w-3 h-3 -ml-0.5 bg-teal-500 border-2 border-white rounded-full"
            />
            <Handle
              type="source"
              position={Position.Right}
              className="w-3 h-3 -mr-0.5 bg-teal-500 border-2 border-white rounded-full"
            />
          </div>
  );
};

export default OpenAINode;