import React, { useState } from 'react';
import { Play, Save, Share2, Download, Upload, Plus, Settings, Loader2, AlertCircle } from 'lucide-react';
import { useFlowStore } from '../../store/flowStore';
import { PipelineExecutor } from '../../utils/pipelineExecutor';

interface WorkflowState {
  isDeployed: boolean;
  hasChanges: boolean;
  lastDeployedAt?: Date;
}

export const Toolbar: React.FC = () => {
  const [workflowName, setWorkflowName] = useState('Untitled Workflow');
  const { nodes, edges, clearWorkflow, updateNodeResults } = useFlowStore();
  const [saveStatus, setSaveStatus] = useState<'saved' | 'saving' | 'unsaved'>('saved');
  const [isRunning, setIsRunning] = useState(false);
  const [executionError, setExecutionError] = useState<string | null>(null);
  const [workflowState, setWorkflowState] = useState<WorkflowState>({
    isDeployed: false,
    hasChanges: false
  });
  const [showDeployModal, setShowDeployModal] = useState(false);

  const handleDeploy = async () => {
    try {
      setWorkflowState(prev => ({
        ...prev,
        isDeployed: true,
        hasChanges: false,
        lastDeployedAt: new Date()
      }));
      // Implement actual deployment logic here
      console.log('Workflow deployed successfully');
    } catch (error) {
      console.error('Deployment failed:', error);
    }
  };

  const handleExport = () => {
    if (!workflowState.isDeployed || workflowState.hasChanges) {
      setShowDeployModal(true);
      return;
    }

    const workflow = {
      name: workflowName,
      nodes,
      edges,
      exportedAt: new Date().toISOString(),
      version: "1.0.0"
    };
    
    const blob = new Blob([JSON.stringify(workflow, null, 2)], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `${workflowName.toLowerCase().replace(/\s+/g, '-')}.json`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
  };

  return (
    <>
      <div className="flex items-center justify-between px-4 py-2 border-b border-gray-200 bg-white">
        <div className="flex items-center space-x-4">
          <input
            type="text"
            value={workflowName}
            onChange={(e) => setWorkflowName(e.target.value)}
            className="text-lg font-semibold text-gray-900 bg-transparent border-none focus:outline-none focus:ring-2 focus:ring-blue-500 focus:ring-offset-2 rounded px-2 py-1"
          />
        </div>
        
        <div className="flex items-center space-x-2">
          <button
            onClick={handleExport}
            className={`p-2 text-gray-600 hover:text-gray-900 hover:bg-gray-100 rounded-md ${
              (!workflowState.isDeployed || workflowState.hasChanges) ? 'opacity-50' : ''
            }`}
            title={
              !workflowState.isDeployed 
                ? "Deploy required before export" 
                : workflowState.hasChanges 
                  ? "Deploy changes before export"
                  : "Export Workflow"
            }
          >
            <Download className="w-4 h-4" />
          </button>

          <button
            onClick={handleDeploy}
            className={`px-4 py-1.5 text-sm font-medium rounded-md flex items-center space-x-1.5 ${
              workflowState.hasChanges
                ? 'bg-blue-600 text-white hover:bg-blue-700'
                : 'bg-gray-100 text-gray-600'
            }`}
          >
            <Play className="w-4 h-4" />
            <span>{workflowState.isDeployed ? 'Update Deployment' : 'Deploy Workflow'}</span>
          </button>
        </div>
      </div>

      {/* Deploy Modal */}
      {showDeployModal && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
          <div className="bg-white rounded-lg shadow-xl p-6 max-w-md w-full mx-4">
            <div className="flex items-center space-x-2 text-amber-600 mb-4">
              <AlertCircle className="w-5 h-5" />
              <h3 className="text-lg font-semibold">Deploy Required</h3>
            </div>
            <p className="text-gray-600 mb-6">
              You have pending changes that need to be deployed before exporting. Deploy your changes first to create an exportable version of this workflow.
            </p>
            <div className="flex justify-end space-x-3">
              <button
                onClick={() => setShowDeployModal(false)}
                className="px-4 py-2 text-sm text-gray-600 hover:text-gray-900"
              >
                Cancel
              </button>
              <button
                onClick={() => {
                  handleDeploy();
                  setShowDeployModal(false);
                }}
                className="px-4 py-2 text-sm bg-blue-600 text-white rounded-md hover:bg-blue-700"
              >
                Deploy Now
              </button>
            </div>
          </div>
        </div>
      )}
    </>
  );
};