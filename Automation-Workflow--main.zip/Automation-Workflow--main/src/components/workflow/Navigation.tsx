import React, { useState } from 'react';
import { 
  Moon, 
  Sun, 
  Search, 
  History, 
  Settings,
  ChevronDown,
  Download,
  AlertCircle 
} from 'lucide-react';
import { NodeCategory } from '../../types/flow';
import { useTheme } from '../../store/themeStore';

interface NavigationProps {
  activeCategory: NodeCategory;
  onCategoryChange: (id: NodeCategory) => void;
  onSearch: (query: string) => void;
}

const categories: { id: NodeCategory; label: string }[] = [
  { id: 'general', label: 'Core Settings' },
  { id: 'llms', label: 'AI Models' },           // This matches the NodePanel category
  { id: 'knowledge-base', label: 'Smart Database' },
  { id: 'integrations', label: 'Connected Apps' },
  { id: 'data-loaders', label: 'Data Import' },
  { id: 'multi-modal', label: 'Mixed Modal' },
  { id: 'logic', label: 'Workflow Rules' },
  { id: 'ai-tools', label: 'AI Tools & SparkLayer' }
];

// Add state for workflow and deploy modal
export const Navigation: React.FC<NavigationProps> = ({
  activeCategory,
  onCategoryChange,
  onSearch,
}) => {
  const { theme, toggleTheme } = useTheme();
  const [showDeployMenu, setShowDeployMenu] = useState(false);
  const [showDeployModal, setShowDeployModal] = useState(false);
  const [workflowState, setWorkflowState] = useState({
    isDeployed: false,
    hasChanges: true
  });

  // Add these functions
  const handleExport = () => {
    if (!workflowState.isDeployed || workflowState.hasChanges) {
      setShowDeployModal(true);
      return;
    }
    // Add export logic here
  };

  // Update the buttons section in the existing JSX
  return (
    <div className={`border-b border-gray-200 ${theme === 'dark' ? 'bg-gray-800' : 'bg-white'}`}>
      <div className="px-4 py-2">
        <div className="flex items-center justify-between mb-4">
          <h1 className={`text-xl font-bold ${theme === 'dark' ? 'text-white' : 'text-gray-900'}`}>
            FlowMind AI
          </h1>
          <div className="flex items-center space-x-2">
            {/* Export Button */}
            <button
              onClick={handleExport}
              className={`flex items-center gap-2 px-3 py-2 rounded-md transition-colors ${
                (!workflowState.isDeployed || workflowState.hasChanges)
                  ? 'bg-amber-50 text-amber-700 hover:bg-amber-100'
                  : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
              }`}
              title={
                !workflowState.isDeployed 
                  ? "Deploy required before export" 
                  : workflowState.hasChanges 
                    ? "Deploy changes before export"
                    : "Export Workflow"
              }
            >
              <Download className="w-4 h-4" />
              {!workflowState.isDeployed || workflowState.hasChanges ? 'Export' : 'Export'}
            </button>

            {/* Existing Version History Button */}
            <button
              className="p-2 text-gray-600 hover:text-gray-900 hover:bg-gray-100 rounded-md"
              title="Version History"
            >
              <History className="w-5 h-5" />
            </button>

            {/* Settings Button */}
            <button
              className="p-2 text-gray-600 hover:text-gray-900 hover:bg-gray-100 rounded-md"
              title="Settings"
            >
              <Settings className="w-5 h-5" />
            </button>

            {/* Deploy Button with Dropdown */}
            <div className="relative">
              <button
                onClick={() => setShowDeployMenu(!showDeployMenu)}
                className="px-4 py-2 bg-blue-600 text-white rounded-md hover:bg-blue-700 flex items-center space-x-2"
              >
                <span>Activate Workflow</span>
                <ChevronDown className="w-4 h-4" />
              </button>

              {showDeployMenu && (
                <div className="absolute right-0 mt-2 w-72 bg-white rounded-md shadow-lg z-50 border border-gray-200">
                  <div className="p-4">
                    <h3 className="text-sm font-medium text-gray-900 mb-2">Deploy your latest changes</h3>
                    <p className="text-xs text-gray-500 mb-3">Choose an update type to match your changes:</p>
                    <div className="space-y-2">
                      <button
                        onClick={() => handleDeploy('core')}
                        className="w-full text-left px-4 py-2 text-sm text-gray-700 hover:bg-blue-50 rounded-md"
                      >
                        • Core Update
                        <span className="block text-xs text-gray-500">For major, architecture-level changes</span>
                      </button>
                      <button
                        onClick={() => handleDeploy('feature')}
                        className="w-full text-left px-4 py-2 text-sm text-gray-700 hover:bg-blue-50 rounded-md"
                      >
                        • Feature Update
                        <span className="block text-xs text-gray-500">For adding or enhancing features</span>
                      </button>
                      <button
                        onClick={() => handleDeploy('quick')}
                        className="w-full text-left px-4 py-2 text-sm text-gray-700 hover:bg-blue-50 rounded-md"
                      >
                        • Quick Fix
                        <span className="block text-xs text-gray-500">For minor bug fixes or refinements</span>
                      </button>
                    </div>
                  </div>
                </div>
              )}
            </div>

            {/* Theme Toggle Button */}
            <button
              onClick={toggleTheme}
              className={`p-2 rounded-md ${
                theme === 'dark' 
                  ? 'bg-gray-700 text-gray-200 hover:bg-gray-600' 
                  : 'bg-gray-100 text-gray-600 hover:bg-gray-200'
              }`}
            >
              {theme === 'dark' ? (
                <Sun className="w-5 h-5" />
              ) : (
                <Moon className="w-5 h-5" />
              )}
            </button>
          </div>
        </div>

        <div className="flex items-center space-x-4">
          <div className="relative flex-1 max-w-xs">
            <Search className={`absolute left-3 top-1/2 transform -translate-y-1/2 w-4 h-4 ${
              theme === 'dark' ? 'text-gray-400' : 'text-gray-500'
            }`} />
            <input
              type="text"
              placeholder="Search nodes..."
              onChange={(e) => onSearch(e.target.value)}
              className={`w-full pl-9 pr-4 py-1.5 text-sm rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500 ${
                theme === 'dark'
                  ? 'bg-gray-700 border-gray-600 text-white placeholder-gray-400'
                  : 'border border-gray-300 text-gray-900 placeholder-gray-500'
              }`}
            />
          </div>
          <nav className="flex space-x-1 overflow-x-auto">
            {categories.map(({ id, label }) => (
              <button
                key={id}
                onClick={() => onCategoryChange(id)}
                className={`flex items-center px-3 py-2 text-sm font-medium rounded-md transition-colors whitespace-nowrap ${
                  activeCategory === id
                    ? theme === 'dark'
                      ? 'bg-blue-900 text-blue-200'
                      : 'bg-blue-50 text-blue-600'
                    : theme === 'dark'
                    ? 'text-gray-300 hover:text-white hover:bg-gray-700'
                    : 'text-gray-600 hover:text-gray-900 hover:bg-gray-50'
                }`}
              >
                {label}
              </button>
            ))}
          </nav>
        </div>
      </div>

      {/* Add Deploy Modal */}
      {showDeployModal && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
          <div className="bg-white rounded-lg shadow-xl p-6 max-w-md w-full mx-4">
            <div className="flex items-center space-x-2 text-amber-600 mb-4">
              <AlertCircle className="w-5 h-5" />
              <h3 className="text-lg font-semibold">Export</h3>
            </div>
            <p className="text-gray-600 mb-6">
            Please deploy your latest changes before exporting. An exportable version of this Workflow is only available after deployment.
            </p>
            <div className="flex justify-end space-x-3">
              <button
                onClick={() => setShowDeployModal(false)}
                className="px-4 py-2 text-sm text-gray-600 hover:text-gray-900"
              >
                Cancel
              </button>
              <button
                onClick={() => {
                  setShowDeployModal(false);
                  setShowDeployMenu(true);
                }}
                className="px-4 py-2 text-sm bg-blue-600 text-white rounded-md hover:bg-blue-700"
              >
                Deploy Now
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};