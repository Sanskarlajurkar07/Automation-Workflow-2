import React, { useEffect, useState } from 'react';
import { useFlowStore } from '../../store/flowStore';
import { Loader2, X, Maximize2, Download, Play, FileAudio, ImageIcon, Upload } from 'lucide-react';

interface ExecuteWorkflowProps {
  onClose: () => void;
}

interface InputValue {
  value: any;
  type: string;
}

const ExecuteWorkflow: React.FC<ExecuteWorkflowProps> = ({ onClose }) => {
  const { nodes, edges } = useFlowStore();
  const [results, setResults] = useState<Record<string, any>>({});
  const [isRunning, setIsRunning] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [inputs, setInputs] = useState<Record<string, InputValue>>({});
  const [activeTab, setActiveTab] = useState<'standard' | 'chatbot' | 'voice'>('standard');

  // Get input and output nodes
  const inputNodes = nodes.filter(node => node.type === 'input');
  const outputNodes = nodes.filter(node => node.type === 'output');

  // Initialize inputs based on input nodes
  useEffect(() => {
    const initialInputs: Record<string, InputValue> = {};
    inputNodes.forEach(node => {
      const inputId = `input_${node.id.split('-')[1]}`;
      initialInputs[inputId] = {
        value: '',
        type: node.data?.params?.type || 'Text'
      };
    });
    setInputs(initialInputs);
  }, [inputNodes]);

  const handleInputChange = (inputId: string, value: any) => {
    setInputs(prev => ({
      ...prev,
      [inputId]: {
        ...prev[inputId],
        value
      }
    }));
  };

  const handleFileInput = async (inputId: string, file: File) => {
    if (!inputs[inputId]) return;

    if (inputs[inputId].type === 'Image' || inputs[inputId].type === 'Audio') {
      const url = URL.createObjectURL(file);
      handleInputChange(inputId, url);
    } else {
      handleInputChange(inputId, file);
    }
  };

  const renderInputField = (inputId: string, input: InputValue) => {
    if (!input) return null;

    switch (input.type) {
      case 'Image':
        return (
          <div className="space-y-2">
            <div className="flex items-center justify-center w-full">
              {input.value ? (
                <div className="relative w-full aspect-video">
                  <img
                    src={input.value}
                    alt="Preview"
                    className="w-full h-full object-cover rounded-md"
                  />
                  <button
                    onClick={() => handleInputChange(inputId, '')}
                    className="absolute top-2 right-2 p-1 bg-red-500 text-white rounded-full"
                  >
                    <X className="w-4 h-4" />
                  </button>
                </div>
              ) : (
                <label className="flex flex-col items-center justify-center w-full h-32 border-2 border-dashed border-gray-300 rounded-lg cursor-pointer hover:bg-gray-50">
                  <div className="flex flex-col items-center justify-center pt-5 pb-6">
                    <ImageIcon className="w-8 h-8 text-gray-400" />
                    <p className="text-sm text-gray-500">Click to upload image</p>
                  </div>
                  <input
                    type="file"
                    className="hidden"
                    accept="image/*"
                    onChange={(e) => e.target.files && handleFileInput(inputId, e.target.files[0])}
                  />
                </label>
              )}
            </div>
          </div>
        );

      case 'Audio':
        return (
          <div className="space-y-2">
            <div className="flex items-center justify-center w-full">
              {input.value ? (
                <div className="w-full p-3 bg-gray-50 rounded-lg">
                  <audio controls className="w-full">
                    <source src={input.value} />
                  </audio>
                  <button
                    onClick={() => handleInputChange(inputId, '')}
                    className="mt-2 text-red-500 hover:text-red-600"
                  >
                    Remove
                  </button>
                </div>
              ) : (
                <label className="flex flex-col items-center justify-center w-full h-32 border-2 border-dashed border-gray-300 rounded-lg cursor-pointer hover:bg-gray-50">
                  <div className="flex flex-col items-center justify-center pt-5 pb-6">
                    <FileAudio className="w-8 h-8 text-gray-400" />
                    <p className="text-sm text-gray-500">Click to upload audio</p>
                  </div>
                  <input
                    type="file"
                    className="hidden"
                    accept="audio/*"
                    onChange={(e) => e.target.files && handleFileInput(inputId, e.target.files[0])}
                  />
                </label>
              )}
            </div>
          </div>
        );

      case 'File':
        return (
          <div className="space-y-2">
            {input.value ? (
              <div className="flex items-center justify-between p-2 bg-gray-50 rounded-md">
                <span className="text-sm text-gray-600">{input.value.name}</span>
                <button
                  onClick={() => handleInputChange(inputId, '')}
                  className="text-red-500 hover:text-red-600"
                >
                  <X className="w-4 h-4" />
                </button>
              </div>
            ) : (
              <label className="flex flex-col items-center justify-center w-full h-24 border-2 border-dashed border-gray-300 rounded-lg cursor-pointer hover:bg-gray-50">
                <div className="flex flex-col items-center justify-center">
                  <Upload className="w-8 h-8 text-gray-400" />
                  <p className="text-sm text-gray-500">Click to upload file</p>
                </div>
                <input
                  type="file"
                  className="hidden"
                  onChange={(e) => e.target.files && handleFileInput(inputId, e.target.files[0])}
                />
              </label>
            )}
          </div>
        );

      default:
        return (
          <input
            type="text"
            value={input.value || ''}
            onChange={(e) => handleInputChange(inputId, e.target.value)}
            placeholder="Enter input..."
            className="w-full px-3 py-2 border border-gray-200 rounded-md text-sm"
          />
        );
    }
  };

  const runWorkflow = async () => {
    setIsRunning(true);
    setError(null);
    try {
      // Execute workflow logic here
      const results = {}; // Replace with actual workflow execution
      setResults(results);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'An unknown error occurred');
    } finally {
      setIsRunning(false);
    }
  };

  return (
    <div className="bg-white rounded-lg shadow-xl w-[600px] max-h-[80vh] overflow-hidden">
      {/* Header */}
      <div className="px-6 py-4 border-b border-gray-200">
        <div className="flex items-center justify-between">
          <h2 className="text-lg font-semibold text-gray-900">Run Pipeline</h2>
          <button onClick={onClose} className="text-gray-400 hover:text-gray-600">
            <X className="w-5 h-5" />
          </button>
        </div>
      </div>

      {/* Tabs */}
      <div className="border-b border-gray-200">
        <div className="flex">
          {['Standard', 'Chatbot', 'Voice'].map((tab) => (
            <button
              key={tab}
              onClick={() => setActiveTab(tab.toLowerCase() as any)}
              className={`px-4 py-2 text-sm font-medium ${
                activeTab === tab.toLowerCase()
                  ? 'text-blue-600 border-b-2 border-blue-600'
                  : 'text-gray-500 hover:text-gray-700'
              }`}
            >
              {tab}
            </button>
          ))}
        </div>
      </div>

      {/* Content */}
      <div className="p-6 space-y-6 overflow-auto max-h-[calc(80vh-4rem)]">
        {/* Inputs */}
        <div className="space-y-4">
          <h3 className="text-sm font-medium text-gray-700">Inputs</h3>
          <div className="space-y-4">
            {inputNodes.map((node) => {
              const inputId = `input_${node.id.split('-')[1]}`;
              return (
                <div key={node.id} className="space-y-2">
                  <label className="block text-xs text-gray-500">{inputId}</label>
                  {inputs[inputId] && renderInputField(inputId, inputs[inputId])}
                </div>
              );
            })}
          </div>
        </div>

        {/* Run Button */}
        <button
          onClick={runWorkflow}
          disabled={isRunning}
          className="w-full py-3 bg-blue-600 text-white rounded-md hover:bg-blue-700 transition-colors disabled:opacity-50 flex items-center justify-center gap-2"
        >
          {isRunning ? (
            <>
              <Loader2 className="w-4 h-4 animate-spin" />
              Running...
            </>
          ) : (
            <>
              <Play className="w-4 h-4" />
              Run Workflow
            </>
          )}
        </button>

        {/* Results */}
        {!isRunning && (
          <div className="space-y-4">
            {error ? (
              <div className="bg-red-50 border border-red-200 rounded-lg p-4 text-red-600">
                <p className="font-medium mb-1">Error executing workflow</p>
                <p className="text-sm">{error}</p>
              </div>
            ) : Object.keys(results).length > 0 && (
              <div className="space-y-4">
                <div className="flex items-center justify-between">
                  <h3 className="text-sm font-medium text-gray-700">Outputs</h3>
                  <span className="text-xs text-green-600 bg-green-50 px-2 py-1 rounded-full">
                    Completed Successfully
                  </span>
                </div>
                {outputNodes.map((node) => (
                  <div key={node.id} className="space-y-2">
                    <div className="flex items-center justify-between">
                      <label className="text-xs text-gray-500">
                        output_{node.id.split('-')[1]}
                      </label>
                      <button className="text-gray-400 hover:text-gray-600">
                        <Download className="w-4 h-4" />
                      </button>
                    </div>
                    <pre className="bg-gray-50 p-4 rounded-lg text-sm text-gray-700 overflow-auto max-h-[200px]">
                      {JSON.stringify(results[`output_${node.id.split('-')[1]}`], null, 2)}
                    </pre>
                  </div>
                ))}
              </div>
            )}
          </div>
        )}
      </div>
    </div>
  );
};

export default ExecuteWorkflow;