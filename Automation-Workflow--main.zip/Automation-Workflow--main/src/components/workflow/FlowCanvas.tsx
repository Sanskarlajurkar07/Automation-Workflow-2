import React, { useCallback, useRef, useLayoutEffect, useState } from 'react';
import ReactFlow,
{
  Background,
  Controls,
  Panel,
  Connection,
  Edge,
  ReactFlowProvider,
  Node,
  MarkerType,
  useReactFlow,
} from 'reactflow';
import 'reactflow/dist/style.css';
import { useFlowStore } from '../../store/flowStore';
import { Save, Download, Play } from 'lucide-react';
import { NodeType } from '../../types/flow';
import CustomEdge from '../CustomEdge';
import InputNode from './types/nodes/InputNode';
import OutputNode from './types/nodes/OutputNode';
import OpenAINode from './types/nodes/openaiNode';
import AnthropicNode from './types/nodes/AnthropicNode';
import GeminiNode from './types/nodes/geminiNode';
import CohereNode from './types/nodes/cohereNode';
import PerplexityNode from './types/nodes/perplexityNode';
import XAINode from './types/nodes/xAINode';
import AWSNode from './types/nodes/AWSNode';
import AzureNode from './types/nodes/AzureNode';
import DocumentToTextNode from './types/nodes/DocumentToTextNode';
import TransformNode from './types/nodes/ScriptsNode';
import PipelineNode from './types/nodes/PipelineNode';
import FileTransformerNode from './types/nodes/FileTransformerNode';
import ShareNode from './types/nodes/Share';
import TextNode from './types/nodes/TextNode';
import KBReaderNode from './types/nodes/KBReaderNode';
import KBLoaderNode from './types/nodes/KBLoaderNode';
import KBSearchNode from './types/nodes/KBSearchNode';
import KBSyncNode from './types/nodes/KBSyncNode';
import AITaskExecutorNode from './types/nodes/AITaskExecutorNode';
import ArxivLoaderNode from './types/nodes/ArxivLoaderNode';
import AudioProcessorNode from './types/nodes/AudioProcessorNode';
import ChatFileReaderNode from './types/nodes/ChatFileReaderNode';
import ChatMemoryNode from './types/nodes/ChatMemoryNode';
import CRMEnricherNode from './types/nodes/CRMEnricherNode';
import CSVLoaderNode from './types/nodes/CSVLoaderNode';
import DataCollectorNode from './types/nodes/DataCollectorNode';
import FileLoaderNode from './types/nodes/FileLoaderNode';
import GitHubNode from './types/nodes/GitHubNode';
import ImageProcessorNode from './types/nodes/ImageProcessorNode';
import JSONHandlerNode from './types/nodes/JSONHandlerNode';
import MergeNode from './types/nodes/MergeNode';
import MongoDBNode from './types/nodes/MongoDBNode';
import MySQLNode from './types/nodes/MySQLNode';
import NotificationNode from './types/nodes/NotificationNode';
import RSSLoaderNode from './types/nodes/RSSLoaderNode';
import TextProcessorNode from './types/nodes/TextProcessorNode';
import TimeAndTTSQLNode from './types/nodes/TimeAndTTSQLNode';
import URLLoaderNode from './types/nodes/URLLoaderNode';
import YouTubeLoaderNode from './types/nodes/YouTubeLoaderNode';
import ConditionNode from './types/nodes/ConditionNode';
import TimeNode from './types/nodes/TimeNode';
import TTSQLNode from './types/nodes/TTSQLNode';
import FileSaveNode from './types/nodes/FileSaveNode';
import NoteNode from './types/nodes/NoteNode';
import ScriptsNode from './types/nodes/ScriptsNode';
import ApiLoaderNode from './types/nodes/ApiLoaderNode';
import MakeWebhookNode from './types/nodes/MakeWebhookNode';
import ZapierWebhookNode from './types/nodes/ZapierWebhookNode';
import TeamsNode from './types/nodes/TeamsNode';
import SlackNode from './types/nodes/SlackNode';
import GoogleDriveNode from './types/nodes/GoogleDriveNode';
import DiscordNode from './types/nodes/DiscordNode';
import OutlookNode from './types/nodes/OutlookNode';
import GmailNode from './types/nodes/GmailNode';
import AirTableNode from './types/nodes/AirTableNode';  
import NotionNode from './types/nodes/NotionNode';
import HubspotNode from './types/nodes/HubspotNode';
import GmailTriggerNode from './types/nodes/GmailTriggerNode';
import OutlookTriggerNode from './types/nodes/OutlookTriggerNode';
import WikiLoaderNode from './types/nodes/WikiLoaderNode';
import ExecuteWorkflow from './executeWorkflow'; // Import ExecuteWorkflow component


const nodeTypes = {
  input: InputNode,
  output: OutputNode,
  openai: OpenAINode,
  anthropic: AnthropicNode,
  gemini: GeminiNode,
  cohere: CohereNode,
  perplexity: PerplexityNode,
  xai: XAINode,
  aws: AWSNode,
  azure: AzureNode,
  'document-to-text': DocumentToTextNode,
  transform: TransformNode,
  pipeline: PipelineNode,
  'file-transformer': FileTransformerNode,
  share: ShareNode,
  text: TextNode,
  condition: ConditionNode,
  'kb-reader': KBReaderNode,
  'kb-loader': KBLoaderNode,
  'kb-search': KBSearchNode,
  'kb-sync': KBSyncNode,
  'ai-task-executor': AITaskExecutorNode,
  'arxiv-loader': ArxivLoaderNode,
  'audio-processor': AudioProcessorNode,
  'chat-file-reader': ChatFileReaderNode,
  'chat-memory': ChatMemoryNode,
  'crm-enricher': CRMEnricherNode,
  'csv-loader': CSVLoaderNode,
  'data-collector': DataCollectorNode,
  'file-loader': FileLoaderNode,
  'github': GitHubNode,
  'image-processor': ImageProcessorNode,
  'json-handler': JSONHandlerNode,
  'merge': MergeNode,
  'mongodb': MongoDBNode,
  'mysql': MySQLNode,
  'notification-node': NotificationNode,
  'rss-loader': RSSLoaderNode,
  'text-processor': TextProcessorNode,
  'time-ttsql': TimeAndTTSQLNode,
  'url-loader': URLLoaderNode,
  'youtube-loader': YouTubeLoaderNode,
  time: TimeNode,
  ttsql: TTSQLNode,
  'file-save': FileSaveNode,
  note: NoteNode,
  scripts: ScriptsNode,
  'api-loader': ApiLoaderNode,
  'make-webhook': MakeWebhookNode,
  'zapier-webhook': ZapierWebhookNode,
  'teams': TeamsNode,
  'slack': SlackNode,
  'google-drive': GoogleDriveNode,
  'discord': DiscordNode,
  'outlook': OutlookNode,
  'gmail': GmailNode,
  'airtable': AirTableNode,
  'notion': NotionNode,
  'hubspot': HubspotNode,
  'gmail-trigger': GmailTriggerNode,
  'outlook-trigger': OutlookTriggerNode,
  'wiki-loader': WikiLoaderNode,

} as const;

const edgeTypes = {
  custom: CustomEdge,
} as const;

export const FlowCanvasContent: React.FC = () => {
  const [showExecutionWindow, setShowExecutionWindow] = useState(false);

  const {
    nodes,
    edges,
    onNodesChange,
    onEdgesChange,
    onConnect,
    setSelectedNode,
    setEdges,
    addNode,
  } = useFlowStore();

  const reactFlowWrapper = useRef<HTMLDivElement>(null);
  const reactFlowInstance = useReactFlow();

  useLayoutEffect(() => {
    const resizeObserver = new ResizeObserver(() => {
      window.dispatchEvent(new Event('resize'));
    });

    if (reactFlowWrapper.current) {
      resizeObserver.observe(reactFlowWrapper.current);
    }

    return () => {
      if (reactFlowWrapper.current) {
        resizeObserver.unobserve(reactFlowWrapper.current);
      }
    };
  }, []);

  const onDragOver = useCallback((event: React.DragEvent) => {
    event.preventDefault();
    event.dataTransfer.dropEffect = 'move';
  }, []);

  const onDrop = useCallback(
    (event: React.DragEvent) => {
      event.preventDefault();

      const type = event.dataTransfer.getData('application/reactflow');
      if (!type) return;

      const position = reactFlowInstance.project({
        x: event.clientX - reactFlowWrapper.current?.getBoundingClientRect().left!,
        y: event.clientY - reactFlowWrapper.current?.getBoundingClientRect().top!,
      });

      const newNode = addNode(type as NodeType, position);

      // Find nearest compatible node
      const compatibleNodes = nodes.filter(node => {
        // Define compatibility rules here
        return true; // Simplified for example
      });

      if (compatibleNodes.length > 0) {
        // Sort by distance and get nearest
        const nearestNode = compatibleNodes.reduce((nearest, node) => {
          const distance = Math.hypot(
            node.position.x - position.x,
            node.position.y - position.y
          );
          return distance < nearest.distance ? { node, distance } : nearest;
        }, { node: compatibleNodes[0], distance: Infinity });

        // Create connection
        const newEdge = {
          id: `e${nearestNode.node.id}-${newNode.id}`,
          source: nearestNode.node.id,
          target: newNode.id,
          type: 'smoothstep',
          markerEnd: { type: MarkerType.ArrowClosed },
        };

        setEdges((eds) => addEdge(newEdge, eds));
      }
    },
    [reactFlowInstance, addNode]
  );

  const onNodeClick = useCallback((event: React.MouseEvent, node: Node) => {
    setSelectedNode(node);
  }, [setSelectedNode]);

  const handleEdgeDelete = (edgeId: string) => {
    setEdges((eds) => eds.filter((edge) => edge.id !== edgeId));
  };

  // Example of adding a ConditionNode dynamically
  const addConditionNode = () => {
    const newNode: Node = {
      id: `condition-${nodes.length}`,
      type: 'condition',
      position: { x: 250, y: 150 },
      data: {
        label: 'Condition Node',
        paths: [
          {
            id: 'path_0',
            clauses: [{ id: 'clause_0', inputField: '', operator: '', value: '' }],
            logicalOperator: 'AND',
          },
        ],
      },
    };
    addNode(newNode, { x: 250, y: 150 });
  };

  // Add download function
  const handleDownloadFlow = () => {
    const flow = {
      nodes,
      edges,
      timestamp: new Date().toISOString(),
      version: "1.0.0"
    };

    // Create blob and download
    const json = JSON.stringify(flow, null, 2);
    const blob = new Blob([json], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = `workflow-${new Date().getTime()}.json`;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    URL.revokeObjectURL(url);
  };

  const handleRunWorkflow = () => {
    setShowExecutionWindow(true);
  };

  return (
    <div ref={reactFlowWrapper} className="flex-1 h-full">
      <ReactFlow
        nodes={nodes}
        edges={edges.map((edge) => ({
          ...edge,
          type: 'custom',
          data: { onDelete: handleEdgeDelete },
        }))}
        onNodesChange={onNodesChange}
        onEdgesChange={onEdgesChange}
        onConnect={onConnect}
        onNodeClick={onNodeClick}
        onDragOver={onDragOver}
        onDrop={onDrop}
        nodeTypes={nodeTypes}
        edgeTypes={edgeTypes}
        fitView
        deleteKeyCode="Delete"
        className="bg-gray-50"
      >
        <Background />
        <Controls />
        {/* Keep only these buttons in the Panel */}
        <Panel position="top-right" className="flex gap-2">
          <button
            onClick={handleRunWorkflow}
            className="flex items-center gap-2 px-4 py-2 bg-green-600 text-white rounded-md hover:bg-green-700"
          >
            <Play className="w-4 h-4" />
            Run Workflow
          </button>
          <button
            className="flex items-center gap-2 px-4 py-2 bg-blue-600 text-white rounded-md hover:bg-blue-700 transition-colors"
            onClick={handleDownloadFlow}
          >
            <Download className="w-4 h-4" />
            Download Workflow
          </button>
          <button
            className="flex items-center gap-2 px-4 py-2 bg-blue-600 text-white rounded-md hover:bg-blue-700 transition-colors"
            onClick={() => {
              console.log('Saving workflow...');
            }}
          >
            <Save className="w-4 h-4" />
            Save Workflow
          </button>
        </Panel>
      </ReactFlow>

      {/* Keep the execution window modal */}
      {showExecutionWindow && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
          <ExecuteWorkflow onClose={() => setShowExecutionWindow(false)} />
        </div>
      )}
    </div>
  );
};

// Create a wrapper component that provides both ReactFlow and Zustand contexts
export const FlowCanvas: React.FC = () => {
  return (
    <ReactFlowProvider>
      <FlowCanvasContent />
    </ReactFlowProvider>
  );
};

export default FlowCanvas;