import React, { useState } from 'react';
import { useFlowStore } from '../../store/flowStore';

interface VariableBuilderProps {
  onSelect: (variable: string) => void;
  filter?: string[];
}

export const VariableBuilder: React.FC<VariableBuilderProps> = ({ onSelect, filter }) => {
  const [selectedNode, setSelectedNode] = useState<string | null>(null);
  const { nodes } = useFlowStore();

  const getNodeOutputFields = (nodeType: string) => {
    // Define output fields for each node type
    const outputFieldMap: Record<string, string[]> = {
      input: ['text'],
      openai: ['response', 'tokens_used'],
      output: ['result'],
      // Add more node types and their output fields
    };
    return outputFieldMap[nodeType] || [];
  };

  const filteredNodes = filter 
    ? nodes.filter(node => filter.includes(node.type))
    : nodes;

  return (
    <div className="absolute z-50 bg-white border border-gray-200 rounded-md shadow-lg p-4 min-w-[200px]">
      {!selectedNode ? (
        <>
          <h3 className="text-sm font-medium text-gray-900 mb-2">Select Node</h3>
          <ul className="space-y-1">
            {filteredNodes.map((node) => (
              <li key={node.id}>
                <button
                  onClick={() => setSelectedNode(node.id)}
                  className="w-full text-left px-2 py-1 text-sm text-gray-700 hover:bg-gray-100 rounded"
                >
                  {node.data.params?.nodeName || node.id}
                </button>
              </li>
            ))}
          </ul>
        </>
      ) : (
        <>
          <h3 className="text-sm font-medium text-gray-900 mb-2">Select Output Field</h3>
          <ul className="space-y-1">
            {getNodeOutputFields(nodes.find(n => n.id === selectedNode)?.type || '').map((field) => (
              <li key={field}>
                <button
                  onClick={() => {
                    const node = nodes.find(n => n.id === selectedNode);
                    onSelect(`{{${node?.data.params?.nodeName || selectedNode}.${field}}}`);
                  }}
                  className="w-full text-left px-2 py-1 text-sm text-gray-700 hover:bg-gray-100 rounded"
                >
                  {field}
                </button>
              </li>
            ))}
          </ul>
        </>
      )}
    </div>
  );
};