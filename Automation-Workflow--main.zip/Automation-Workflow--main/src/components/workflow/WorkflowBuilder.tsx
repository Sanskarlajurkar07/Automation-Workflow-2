import React, { useState } from 'react';
import { Navigation } from './Navigation';
import { NodePanel } from './NodePanel';
import { FlowCanvas } from './FlowCanvas';
import { ErrorBoundary } from '../ErrorBoundary';
import { NodeCategory } from '../../types/flow';

export const WorkflowBuilder = () => {
  const [searchQuery, setSearchQuery] = useState('');
  const [activeCategory, setActiveCategory] = useState<NodeCategory>('general');

  const categoryMap: Record<string, NodeCategory> = {
    'Core Settings': 'general',
    'AI Models': 'llms',
    'Smart Database': 'knowledge-base',
    'Connected Apps': 'integrations',
    'Data Import': 'data-loaders',
    'Mixed Modal': 'multi-modal',
    'Workflow Rules': 'logic',
    'AI Tools & SparkLayer': 'ai-tools'
  };

  return (
    <div className="min-h-screen bg-gray-50">
      <Navigation
        activeCategory={activeCategory}
        onCategoryChange={setActiveCategory}
        onSearch={setSearchQuery}
      />
      <div className="flex h-[calc(100vh-132px)]">
        <div className="w-64 border-r border-gray-200 bg-white overflow-y-auto">
          <ErrorBoundary>
            <NodePanel
              category={activeCategory}
              searchQuery={searchQuery}
              onDragStart={(event, nodeType) => {
                event.dataTransfer.setData('application/reactflow', nodeType);
                event.dataTransfer.effectAllowed = 'move';
              }}
            />
          </ErrorBoundary>
        </div>
        <div className="flex-1">
          <FlowCanvas />
        </div>
      </div>
    </div>
  );
};