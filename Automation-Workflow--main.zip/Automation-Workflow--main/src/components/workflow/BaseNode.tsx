import React, { memo } from 'react';
import { Handle, Position, NodeProps } from 'reactflow';
import { Trash2 } from 'lucide-react';
import { useFlowStore } from '../../store/flowStore';
import RenderNodeContent from './types/RenderNodeContent';

interface BaseNodeProps extends NodeProps {
  icon?: React.ReactNode;
  inputs?: string[];
  outputs?: string[];
}

export const BaseNode = memo(({ data, id, selected, icon: Icon, inputs = [], outputs = [] }: BaseNodeProps) => {
  const removeNode = useFlowStore((state) => state.removeNode);
  const updateNodeData = useFlowStore((state) => state.updateNodeParams);

  const renderInputHandles = () => {
    return inputs.map((input, index) => (
      <Handle
        key={`input-${index}`}
        type="target"
        position={Position.Left}
        id={input}
        className="w-3 h-3 bg-gray-400 border-2 border-white rounded-full"
        style={{ left: -6, top: `${50 + index * 20}%`, transform: 'translateY(-50%)' }}
      />
    ));
  };

  const renderOutputHandles = () => (
    <Handle
      type="source"
      position={Position.Right}
      id="output"
      className="w-3 h-3 bg-blue-500 border-2 border-white rounded-full"
      style={{ right: -6, top: '50%' }}
    />
  );

  return (
    <div
      className={`relative bg-white rounded-lg shadow-md border-2 ${
        selected ? 'border-blue-500' : 'border-gray-200'
      }`}
    >
      <div className="p-3">
        <div className="flex items-center justify-between mb-2">
          <div className="flex items-center space-x-2">
            {Icon && <div className="text-blue-600">{Icon}</div>}
            <div className="text-sm font-medium text-gray-900">{data.label}</div>
          </div>
          <button
            onClick={() => removeNode(id)}
            className="text-gray-400 hover:text-red-500 transition-colors"
          >
            <Trash2 className="w-4 h-4" />
          </button>
        </div>

        <RenderNodeContent
          type={data.type}
          data={data}
          id={id}
          updateNodeData={updateNodeData}
          removeNode={removeNode}
        />
      </div>

      {renderInputHandles()}
      {renderOutputHandles()}
    </div>
  );
});

BaseNode.displayName = 'BaseNode';